function logging(value) {
	debug(value);
	return value;
}